/**
 * Dev-only trace tool: click around a shape on the map, name it, and save it as
 * a JSON file. Loaded lazily and only when `import.meta.env.DEV` is true, so it
 * is not part of the production build.
 *
 * Two pieces render from here:
 *   - a drawing layer, portalled into the map's SVG so it shares the map's zoom
 *   - a control panel over the map
 */
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { UiIcon } from '@/components/common/UiIcon';
import { cx } from '@/components/common/cx';
import type { MapViewport } from '@/hooks/useMapViewport';
import { formatLocationJson } from '@/lib/content/formatLocation';
import { ID_PATTERN } from '@/lib/content/validateWorld';
import type { WorldIndex } from '@/lib/content/worldIndex';
import { defaultParent, nearestVertex, parentOptions, roundCoordinate, slugify, type TraceKind } from '@/lib/map/trace';
import { computeVisibility } from '@/lib/map/visibility';
import { LOCATION_ICONS, isArea, type LocationIconName, type Point } from '@/types/world';
import styles from './Trace.module.css';

interface TraceToolProps {
  index: WorldIndex;
  selectedId: string | null;
  viewport: MapViewport;
  /** An <g> inside the map's SVG for the drawing layer. */
  layerSlot: SVGGElement | null;
}

const KINDS: { value: TraceKind; label: string }[] = [
  { value: 'country', label: 'Country' },
  { value: 'region', label: 'Region' },
  { value: 'city', label: 'City' },
  { value: 'poi', label: 'Point of interest' },
];
const FOLDER: Record<TraceKind, string> = {
  country: 'countries',
  region: 'regions',
  city: 'cities',
  poi: 'points-of-interest',
};
const isAreaKind = (kind: TraceKind) => kind === 'country' || kind === 'region';

/** Pixels within which a click snaps to an existing corner. */
const SNAP_PX = 10;
/** Pixels of pointer travel beyond which a press was a drag (pan), not a click. */
const DRAG_PX = 5;

const store = {
  get: (key: string) => {
    try {
      return sessionStorage.getItem(`trace.${key}`);
    } catch {
      return null;
    }
  },
  set: (key: string, value: string | null) => {
    try {
      if (value === null) sessionStorage.removeItem(`trace.${key}`);
      else sessionStorage.setItem(`trace.${key}`, value);
    } catch {
      /* private mode etc: the tool still works, it just forgets between reloads */
    }
  },
};

export default function TraceTool({ index, selectedId, viewport, layerSlot }: TraceToolProps) {
  const [enabled, setEnabled] = useState(() => store.get('enabled') === '1');
  const [kind, setKind] = useState<TraceKind>(() => (store.get('kind') as TraceKind | null) ?? 'region');
  const [points, setPoints] = useState<Point[]>([]);
  const [name, setName] = useState('');
  const [idOverride, setIdOverride] = useState<string | null>(null);
  const [parentChoice, setParentChoice] = useState<string | null>(null);
  const [icon, setIcon] = useState<LocationIconName | ''>('');
  const [snap, setSnap] = useState<Point | null>(null);
  const [saving, setSaving] = useState(false);
  const [side, setSide] = useState<'left' | 'right'>(() => (store.get('side') === 'left' ? 'left' : 'right'));
  // A note left just before the page reloaded after a save. Read here, cleared in an
  // effect: initializers must be side-effect free (React runs them twice in dev).
  const [status, setStatus] = useState<{ tone: 'ok' | 'error'; text: string } | null>(() => {
    const flash = store.get('flash');
    return flash ? { tone: 'ok', text: flash } : null;
  });

  useEffect(() => store.set('flash', null), []);
  useEffect(() => store.set('enabled', enabled ? '1' : '0'), [enabled]);
  useEffect(() => store.set('kind', kind), [kind]);
  useEffect(() => store.set('side', side), [side]);

  const areaKind = isAreaKind(kind);
  const selected = selectedId ? index.get(selectedId) : undefined;
  const mapWidth = index.world.map.width;

  // ---- derived form state --------------------------------------------------
  const options = useMemo(() => parentOptions(index, kind), [index, kind]);
  const fallbackParent = useMemo(() => defaultParent(index, kind, selectedId), [index, kind, selectedId]);
  const parentId = options.some((o) => o.id === parentChoice) ? parentChoice : options.some((o) => o.id === fallbackParent) ? fallbackParent : (options[0]?.id ?? null);
  const id = idOverride ?? slugify(name);
  const existing = id ? index.get(id) : undefined;

  const ready =
    name.trim().length > 0 &&
    ID_PATTERN.test(id) &&
    (areaKind ? points.length >= 3 : points.length === 1) &&
    (kind === 'country' || parentId !== null);

  const data = useMemo(() => {
    const out: Record<string, unknown> = { id, name: name.trim(), type: kind };
    if (kind !== 'country' && parentId) out.parent = parentId;
    if (!areaKind && icon) out.icon = icon;
    if (areaKind) out.polygon = points;
    else if (points[0]) out.coordinates = { x: points[0][0], y: points[0][1] };
    return out;
  }, [id, name, kind, parentId, icon, areaKind, points]);

  /** Corners of everything currently visible: what new points can snap to. */
  const vertices = useMemo(() => {
    const visible = computeVisibility(index, selectedId);
    const areaIds = [...index.countries().map((c) => c.id), ...visible.regionIds];
    return areaIds.flatMap((areaId) => {
      const location = index.require(areaId);
      return isArea(location) ? location.polygon : [];
    });
  }, [index, selectedId]);

  // ---- map interaction -----------------------------------------------------
  useEffect(() => {
    const container = viewport.containerRef.current;
    const svg = viewport.svgRef.current;
    if (!enabled || !container || !svg) return;

    container.dataset.tracing = 'true';
    let pressed: { x: number; y: number } | null = null;

    const locate = (e: MouseEvent | PointerEvent): { raw: Point; snapped: Point | null } | null => {
      const raw = viewport.clientToMap(e.clientX, e.clientY);
      if (!raw) return null;
      return { raw, snapped: e.altKey ? null : nearestVertex(vertices, raw, SNAP_PX / viewport.getScale()) };
    };

    const onDown = (e: PointerEvent) => {
      pressed = { x: e.clientX, y: e.clientY };
    };
    const onMove = (e: PointerEvent) => {
      const found = svg.contains(e.target as Node) ? locate(e) : null;
      setSnap((prev) => {
        const next = found?.snapped ?? null;
        return prev?.[0] === next?.[0] && prev?.[1] === next?.[1] ? prev : next;
      });
    };
    // Capture phase on the container so this runs before the shapes' own click handlers.
    const onClick = (e: MouseEvent) => {
      if (!svg.contains(e.target as Node)) return; // clicks on buttons and panels are left alone
      if (pressed && Math.hypot(e.clientX - pressed.x, e.clientY - pressed.y) >= DRAG_PX) return; // that was a pan
      const found = locate(e);
      if (!found) return;
      e.stopPropagation();
      e.preventDefault();
      const point: Point = found.snapped ?? [roundCoordinate(found.raw[0], mapWidth), roundCoordinate(found.raw[1], mapWidth)];
      setStatus(null);
      setPoints((prev) => (areaKind ? [...prev, point] : [point]));
    };

    container.addEventListener('pointerdown', onDown, true);
    container.addEventListener('pointermove', onMove);
    container.addEventListener('click', onClick, true);
    return () => {
      delete container.dataset.tracing;
      container.removeEventListener('pointerdown', onDown, true);
      container.removeEventListener('pointermove', onMove);
      container.removeEventListener('click', onClick, true);
      setSnap(null);
    };
  }, [enabled, areaKind, vertices, viewport, mapWidth]);

  // Backspace / Ctrl+Z remove the last point; Esc clears the shape (instead of stepping up a level).
  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent) => {
      const typing = e.target instanceof HTMLElement && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName);
      if (typing || points.length === 0) return;
      if (e.key === 'Backspace' || ((e.ctrlKey || e.metaKey) && e.key === 'z')) {
        e.preventDefault();
        setPoints((prev) => prev.slice(0, -1));
      } else if (e.key === 'Escape') {
        e.preventDefault(); // tells the page not to also navigate up
        setPoints([]);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [enabled, points.length]);

  // ---- actions -------------------------------------------------------------
  const reset = () => {
    setPoints([]);
    setName('');
    setIdOverride(null);
    setIcon('');
  };

  /** Load an existing place into the form so it can be re-traced (its file is updated in place). */
  const redraw = () => {
    if (!selected) return;
    setKind(selected.type);
    setPoints([]);
    setName(selected.name);
    setIdOverride(selected.id);
    setParentChoice(selected.parent);
    setIcon(!isArea(selected) && selected.icon ? selected.icon : '');
    setStatus(null);
  };

  const changeKind = (next: TraceKind) => {
    if (next === kind) return;
    if (!(isAreaKind(next) && areaKind)) setPoints([]); // a polygon can't become a point, or vice versa
    setParentChoice(null);
    setKind(next);
  };

  const save = async () => {
    setSaving(true);
    setStatus(null);
    try {
      const response = await fetch(`${import.meta.env.BASE_URL}__atlas/save`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ folder: FOLDER[kind], id, data }),
      });
      const result = (await response.json()) as { path?: string; overwritten?: boolean; error?: string };
      if (!response.ok || !result.path) throw new Error(result.error ?? 'Save failed.');
      // Saving changes a data file, so Vite reloads the page. Leave a note to show afterwards.
      store.set('flash', `${result.overwritten ? 'Updated' : 'Saved'} ${result.path}`);
      reset();
    } catch (error) {
      setStatus({ tone: 'error', text: error instanceof Error ? error.message : 'Save failed.' });
    } finally {
      setSaving(false);
    }
  };

  const copy = async () => {
    await navigator.clipboard?.writeText(formatLocationJson(data));
    setStatus({ tone: 'ok', text: `Copied. Save it as src/data/locations/${FOLDER[kind]}/${id}.json` });
  };

  // ---- drawing layer ---------------------------------------------------------
  const path = points.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x} ${y}`).join(' ') + (points.length >= 3 ? ' Z' : '');
  const layer: ReactNode = (
    <g className={styles.layer} aria-hidden="true">
      {areaKind && points.length >= 2 && <path d={path} className={cx(styles.shape, points.length >= 3 && styles.shapeClosed)} />}
      {points.map(([x, y], i) => (
        <g key={i} transform={`translate(${x} ${y})`}>
          <g className={styles.dotScale}>
            <circle className={cx(styles.dot, i === points.length - 1 && styles.dotLast)} r={i === 0 && areaKind && points.length >= 3 ? 6 : 4.5} />
          </g>
        </g>
      ))}
      {snap && (
        <g transform={`translate(${snap[0]} ${snap[1]})`}>
          <g className={styles.dotScale}>
            <circle className={styles.snap} r={10} />
          </g>
        </g>
      )}
    </g>
  );

  const help = !areaKind
    ? 'Click where it goes on the map. Click again to move it.'
    : points.length === 0
      ? 'Click around the edge of the shape. Corners of existing shapes are snapped to (hold Alt to turn that off). Drag to pan, scroll to zoom.'
      : points.length < 3
        ? 'Keep clicking around the edge. The shape closes itself.'
        : 'Add more points, or fill in the details below and Save. Backspace removes the last point.';

  return (
    <>
      <button type="button" className={cx(styles.toggle, enabled && styles.toggleOn)} aria-pressed={enabled} onClick={() => setEnabled((v) => !v)}>
        <UiIcon name="pencil" size={18} />
        Trace
      </button>

      {enabled && layerSlot && createPortal(layer, layerSlot)}

      {enabled && (
        <section className={cx(styles.panel, side === 'left' && styles.panelLeft)} aria-label="Trace tool">
          <header className={styles.panelHeader}>
            <h2>Trace tool</h2>
            <button
              type="button"
              onClick={() => setSide((s) => (s === 'right' ? 'left' : 'right'))}
              title="Move this panel to the other side of the map"
              aria-label="Move panel to the other side"
            >
              <UiIcon name="swap" size={16} />
              Move
            </button>
          </header>
          <p className={styles.help}>{help}</p>

          {selected && (
            <button type="button" className={styles.redraw} onClick={redraw}>
              Redraw “{selected.name}”
            </button>
          )}

          <div className={styles.kinds} role="group" aria-label="What are you drawing?">
            {KINDS.map((k) => (
              <button key={k.value} type="button" className={cx(kind === k.value && styles.kindOn)} aria-pressed={kind === k.value} onClick={() => changeKind(k.value)}>
                {k.label}
              </button>
            ))}
          </div>

          <div className={styles.progress}>
            <span>
              {areaKind ? `${points.length} ${points.length === 1 ? 'point' : 'points'}` : points[0] ? `x ${points[0][0]}   y ${points[0][1]}` : 'No point yet'}
            </span>
            <span className={styles.progressButtons}>
              <button type="button" onClick={() => setPoints((p) => p.slice(0, -1))} disabled={points.length === 0}>
                Undo
              </button>
              <button type="button" onClick={() => setPoints([])} disabled={points.length === 0}>
                Clear
              </button>
            </span>
          </div>

          <label className={styles.field}>
            Name
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Northern March" />
          </label>

          {kind !== 'country' && (
            <label className={styles.field}>
              Inside
              <select value={parentId ?? ''} onChange={(e) => setParentChoice(e.target.value)}>
                {options.length === 0 && <option value="">(nothing to put it in yet)</option>}
                {options.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </select>
            </label>
          )}

          {!areaKind && (
            <label className={styles.field}>
              Icon
              <select value={icon} onChange={(e) => setIcon(e.target.value as LocationIconName | '')}>
                <option value="">Default</option>
                {LOCATION_ICONS.map((i) => (
                  <option key={i} value={i}>
                    {i}
                  </option>
                ))}
              </select>
            </label>
          )}

          <label className={styles.field}>
            File name (id)
            <input value={id} onChange={(e) => setIdOverride(e.target.value)} spellCheck={false} />
          </label>

          {existing && (
            <p className={styles.note}>
              “{existing.name}” already uses this id. Saving replaces its {areaKind ? 'outline' : 'position'}; its summary and other settings are kept.
            </p>
          )}
          {id && !ID_PATTERN.test(id) && <p className={styles.note}>Ids use lowercase letters, digits and hyphens only.</p>}
          {status && <p className={cx(styles.status, status.tone === 'error' && styles.statusError)}>{status.text}</p>}

          <div className={styles.actions}>
            <button type="button" className={styles.primary} onClick={save} disabled={!ready || saving}>
              {saving ? 'Saving…' : existing ? 'Replace' : 'Save'}
            </button>
            <button type="button" onClick={copy} disabled={!ready}>
              Copy JSON
            </button>
          </div>
          <p className={styles.fine}>
            Saves to <code>src/data/locations/{FOLDER[kind]}/{id || '…'}.json</code>
          </p>
        </section>
      )}
    </>
  );
}
